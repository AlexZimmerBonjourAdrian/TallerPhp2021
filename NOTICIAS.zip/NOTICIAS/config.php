<?php

// Define DB Params
define("DB_HOST", "localhost");
define("DB_USER", "root");
define("DB_PASS", "root");
define("DB_NAME", "shareboard");

// Define URL
define("ROOT_PATH", "/NOTICIAS/");
define("ROOT_URL", "http://localhost:8888/NOTICIAS/");